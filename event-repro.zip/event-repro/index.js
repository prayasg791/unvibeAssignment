require("./notifications");
const webhook = require("./webhook");

webhook.handlePaymentSucceeded(1);
