const events = require("./events");

events.on("order.paid", (payload) => {
  console.log(`receipt sent for order ${payload.orderId}`);
});
