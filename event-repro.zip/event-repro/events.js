const handlers = {};

function on(name, fn) {
  (handlers[name] = handlers[name] || []).push(fn);
}

function emit(name, payload) {
  (handlers[name] || []).forEach((fn) => fn(payload));
}

module.exports = { on, emit };
