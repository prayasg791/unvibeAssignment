const events = require("./events");

function handlePaymentSucceeded(orderId) {
  console.log(`credit recorded for order ${orderId}`);
  events.emit("order.payed", { orderId });
}

module.exports = { handlePaymentSucceeded };
